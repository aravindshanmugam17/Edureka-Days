import React from 'react';


class Form extends React.Component{
    constructor(){
       super()
       this.state={
             isClicked:false,
             FN:'',
             rollNo:''
       }
    }
    handleClick=()=>{
        this.setState({isClicked:true})
       }
       handleNameChange=(event)=>{
        this.setState({FN:event.target.value})
       }
       handleRollNoChange=(event)=>{
        this.setState({rollNo:event.target.value})
       }
       handleSubmit=(event)=>{
          event.preventDefault();
          alert("Form Submited Succesfully")
       }
    render(){
        if(!this.state.isClicked){
            return(
                <div>
                    <h3>MERN stack developer</h3>
                    <button onClick={this.handleClick}>Apply now</button>
                </div>
            )
        }
        else{
        return(
            <div>
                <h3>MERN stcak develpoer</h3>
                <form onSubmit={this.handleSubmit}>
                    <span>User name:</span>
                    <input type="text" onChange={this.handleNameChange}/>
                    <br/>
                    <span>Roll Number:</span>
                    <input type="text" onChange={this.handleRollNoChange}/>
                    <br/>
                    <input type='submit' value="submit now"/>
                </form>
            </div>
        )
        
    }
    }
}


export default Form;