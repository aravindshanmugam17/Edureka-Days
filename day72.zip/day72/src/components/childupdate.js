import React from "react";


class ChildUpdating extends React.Component{

    
    static getDerivedStateFromProps(){
        console.log("Component B: getDerivedStateFromProps() Method");
    }

    shouldComponentUpdate(){
        console.log("Component B: shouldComponentUpdate() Method");
    }

    componentDidUpdate(){
        console.log(" Component B: componentDidUpdate() Method");
    }


    getSnapshotBeforeUpdate(){
        console.log(" Component B: getSnapshotBeforeUpdate() Method");
    }
    render(){
        console.log("Component B: render() Method")
        return(
            <div>
                <h1>Updating Phase...</h1>
                 
            </div>
        )
    }
}
export default ChildUpdating;

