import React from "react";

import ChildMounting from "./ChildMounting";
import Updating from "./Parentupdate";

class Mounting extends React.Component{

    constructor(){
        super()
        console.log("Component A: Constructor() Method");
    }

    static getDerivedStateFromProps(){
        console.log("Component A: getDerivedStateFromProps() Method  ");
    }

    componentDidMount(){
        console.log("Component A: componentDidMount() Method");
    }
    render(){
        console.log("Component A: render() Method ")
        return(
            <div>
                <h1>Mounting Phase...</h1>
                <ChildMounting />
                <Updating />
            </div>
        )
    }
}
export default Mounting;