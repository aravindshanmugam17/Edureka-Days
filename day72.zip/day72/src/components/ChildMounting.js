import React from "react";

class ChildMounting extends React.Component{

    constructor(){
        super()
        console.log("Component B: constructor() Method");
    }

    static getDerivedStateFromProps(){
        console.log("Component B: getDerivedStateFromProps() Method");
    }

    componentDidMount(){
        console.log("Component B: componentDidMount() Method");
    }
    render(){
        console.log("Component B: render() Method")
        return(
            <div>
                <h1>Mounting Phase...</h1>
            </div>
        )
    }
}
export default ChildMounting;