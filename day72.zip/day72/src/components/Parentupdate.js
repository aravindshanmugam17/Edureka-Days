import React from "react";

import ChildUpdating from "./childupdate";

class Updating extends React.Component{
    constructor(){
        super()
       this.state= {
           value:0
        }
    }
    
    handleClick=()=>{
      this.setState({value:1})
    }
    static getDerivedStateFromProps(){
        console.log("Component A: getDerivedStateFromProps() Method");
    }

    shouldComponentUpdate(){
        console.log("Component A: shouldComponentUpdate() Method");
    }

    componentDidUpdate(){
        console.log(" Component A: componentDidUpdate() Method");
    }


    getSnapshotBeforeUpdate(){
        console.log(" Component A: getSnapshotBeforeUpdate() Method");
    }
    render(){
        console.log("Component A: render() Method")
        return(
            <div>
                <h1>Updating Phase...</h1>
                <ChildUpdating />
                 <button onClick={this.handleClick}>UPDATE</button>
            </div>
        )
    }
}
export default Updating;

