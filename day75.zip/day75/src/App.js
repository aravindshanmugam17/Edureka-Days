import logo from './logo.svg';
import './App.css';
import Map from './Components/Map';
import React from 'react';
class  App extends React.Component {
  render(){
  return (
    <div className="App">
          <Map/>
    </div>
  );
}
}

export default App;
