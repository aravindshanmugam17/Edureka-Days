import React from 'react'

class Map extends React.Component{
    constructor(){
        super();
        this.state={
            originalusers:[],
            filterdusers:[],
            inputId:undefined
        }
    }
    componentDidMount(){
        fetch('https://jsonplaceholder.typicode.com/users')
        .then(response=>response.json())
        .then(output=>this.setState({originalusers:output,filterdusers:output}))
        .catch(err=>console.log(err))
    }
    handleChange=(event)=>{
        this.setState({inputId:event.target.value})
    }
    handleSubmit=()=>{
        const{originalusers,inputId}=this.state;
        let arr;
        if(inputId!=''){
            arr=originalusers.filter((item)=>item.id==inputId);
        }else{
              arr=originalusers;
        }
        this.setState({filterdusers:arr});
    }
    render(){
        const{filterdusers}=this.state;
        return(
            <div>
                <table border={1}>
                    <tr>
                        <td>Id</td>
                        <td>Name</td>
                        <td>Email</td>
                        <td>Phone Number</td>
                    </tr>
                    {filterdusers.map((value)=>{
                        return<tr>
                            <td>{value.id}</td>
                            <td>{value.name}</td>
                            <td>{value.email}</td>
                            <td>{value.phone}</td>
                        </tr>
                    })}
                </table>
                <input type='text' onChange={this.handleChange}/>
                <button onClick={this.handleSubmit}>submit</button>
            </div>
        )
    }
}


export default Map;