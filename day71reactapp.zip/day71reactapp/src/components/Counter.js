import React from "react";
 class Counter extends React.Component{
    constructor(){
        super();
        this.state={
            counter:0
        }
    }
    increment=()=>{
        this.setState((prevstate)=>(
         {counter:prevstate.counter+1}
        ))
    }
    decrement=()=>{
        this.setState((prevstate)=>(
         {counter:prevstate.counter-1}
        ))
    }
    reset=()=>{
        this.setState((prevstate)=>(
         {counter:0}
        ))
    }
    render(){
        return(
            <div>
           <h1>{this.state.counter}</h1>
           <button onClick={this.decrement}>Decrement</button>
           <button onClick={this.increment}>Increment</button>  
           <button onClick={this.reset}>Reset</button>  

           </div>
        )
    }
 }
 export default Counter