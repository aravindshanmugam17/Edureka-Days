import React from "react";

import Child from "./Child";
import Counter from "./Counter";


class Parent extends React.Component{
 render(){
    return(
        <div>
          <h1>USERS</h1>
          <Child fName="DINESH" lName="JAYAVEL"/>
          <Child fName="MAHENDRA SINGH" lName="DHONI"/>
          <Child fName="KANE" lName="WILLIAMSON"/>
          <Counter />
        </div>
    )
 }

}

export default Parent;