import React from 'react';
import Child from './Child'
import Child2 from './Child2'
class Parent extends React.Component{
    constructor(){
        super();
        this.state={
            value:"intial value"
        }
    }
    handleCallback=(recivedvalue)=>{
       
    this.setState({value:recivedvalue});
    }
      render(){
        return(
            <div>
            parent component
            <Child callbackMethod={this.handleCallback}/>
            <Child2 text={this.state.value}/>
            </div>

        )
      }
}
export default Parent;