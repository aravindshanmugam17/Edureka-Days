import React from 'react';
 class Child extends React.Component{
    handleClick=()=>{
        this.props.callbackMethod("data from the child");
    }
    render(){
        return(
            <div>
                  <button onClick={this. handleClick}>Transfer data</button>
            </div>
        )
    }
 }

 export default Child;