import React from 'react';
class Child2 extends React.Component{
    render(){
        return(
            <div>
                {this.props.text}
            </div>
        )
    }
}
export default Child2;