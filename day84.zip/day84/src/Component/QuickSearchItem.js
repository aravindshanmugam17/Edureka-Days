import React from "react";
 class Quicksearchitems extends React.Component{
    render(){
        return(
            <div>
                 <div className="qs-box col-12 col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
                 <div className="qs-box-contents">
                 <img src="https://www.healthshots.com/wp-content/uploads/2020/01/idli-lead-.jpg" alt="iimage not found" className="qs-image" />         \
                <h4 className="qs-item-heading">Breakfast</h4>
                <p className="qs-item-description">Start your day with exclusive breakfast options</p>
               </div>
                </div>

                <div className="qs-box col-12 col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
        <div className="qs-box-contents">
            <img src="https://lh3.googleusercontent.com/VEvK3Lo37IeNY4-C7_i-zLc93gnHFnKghKQKCOIDdPHdgqUC6w1udYcWY33q9PuPVvCDPh5CC3BUcLw878yYl-Jc9jvHLI9bfuLhG0g4=w512-rw" alt="iimage not found" className="qs-image" />
            <h4 className="qs-item-heading">Lunch</h4>
            <p className="qs-item-description">Start your day with exclusive lunch options</p>
        </div>
       </div>
       <div className="qs-box col-12 col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
        <div className="qs-box-contents">
            <img src="https://dwellbymichelle.com/wp-content/uploads/2021/03/DWELL-Samosa-Recipe.jpeg" alt="iimage not found" className="qs-image" />
            <h4 className="qs-item-heading">Snacks</h4>
            <p className="qs-item-description">Start your day with exclusive Snacks options</p>
        </div>
       </div>
       <div className="qs-box col-12 col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
        <div className="qs-box-contents">
            <img src="https://mybayutcdn.bayut.com/mybayut/wp-content/uploads/American-Breakfast-in-Dubai-_-Cover_14-9-22.jpg" alt="iimage not found" className="qs-image" />
            <h4 className="qs-item-heading">Dinner</h4>
            <p className="qs-item-description">Start your day with exclusive Dinner options</p>
        </div>
       </div>
       <div className="qs-box col-12 col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
        <div className="qs-box-contents">
            <img src="https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/drink-to-order-at-the-bar-1642641671.png?crop=1.00xw:0.371xh;0,0.350xh&resize=980:*" alt="iimage not found" className="qs-image" />
            <h4 className="qs-item-heading">Drinks</h4>
            <p className="qs-item-description">Start your day with exclusive Drinks options</p>
        </div>
       </div>
       <div className="qs-box col-12 col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
        <div className="qs-box-contents">
            <img src="https://img.traveltriangle.com/blog/wp-content/uploads/2018/10/nightlife-in-bahamas-cover-image.jpg" alt="iimage not found" className="qs-image" />
            <h4 className="qs-item-heading">Nightlife</h4>
            <p className="qs-item-description">Start your day with exclusive Nightlife options</p>
        </div>
       </div>
            </div>
        )
    }
 }
 export default Quicksearchitems