import React from "react"
class Wallpaper extends React.Component{
    render(){
      const {locationsData}=this.props;

        return(
            <div>
            <img src="https://media.istockphoto.com/id/500516612/photo/enjoying-dinner-with-friends.jpg?s=1024x1024&w=is&k=20&c=ply0ofr8l0DhhYyyV6rn9oKVAZwzag_4fy5ICBwnHUI=" alt="image not found" width="100%" height="550px" />
            <div className="topsection">
            <div className="logo">e! </div>
            <div className="headdescription"> Find the best restarunts,cafes,and bars</div>
          <div className="searchoptions">
          <span>
            <select className="locationbox">
                <option value="0">Select</option>
                {locationsData.map((item)=>{
                  return<option value="1">{`${item.name}, ${item.city}`}</option>
                })}
                
                
            </select>
          </span>
          <span className="searchbox">
            <svg className="icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
              </svg>
            <input type="text" className="searchinput" placeholder="Search for restarunts" />
          </span>
          </div>
         </div>
         </div> 
         )
}
}
export  default Wallpaper