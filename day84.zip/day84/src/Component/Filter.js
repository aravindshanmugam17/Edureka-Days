import React from "react";
import '../Styles/filter.css';


class Filter extends React.Component{
    render(){
        return(
            <div>
                 <div className="container">
    <div className="row heading d-flex justify-content-center">
      Breakfast places in Salem
    </div>
    <div className="row">
      <div className="col-sm-12 col-md-4 col-lg-3">
        <div className="filterPanel">
          <div className="filterPanelHeading">
            Filters
          </div>
          <div className="filterPannelSubHeading">
            Select Location
          </div>
          <select className="locationSelection">
            <option>Salem</option>
            <option>Erode</option>
            <option>Namakkal</option>
            <option>Coimbatore</option>
          </select>
          <div className="filterPanelSubHeading">Cuisine</div>
          <input type="checkbox" className="cuisinOption" />
            <label>North Indian</label>
          
          <br/>
          <input type="checkbox" className="cuisinOption" />
            <label>South Indian</label>
         
          <br/>
          <input type="checkbox" className="cuisinOption" />
            <label>Chinese</label>
          
          <br />
          <input type="checkbox" className="cuisinOption" />
            <label>Fast Food</label>
          
          <br/>
          <input type="checkbox" className="cuisinOption" />
            <label>Street Food</label>
          
          <br/>
          <div className="filterPanelSubHeading">
            Cost for two
          </div>
          <input type="radio" className="cuisinOption" name="cost" />
            <label>Less than 500</label>
          
          <br/>
          <input type="radio" className="cuisinOption" name="cost" />
            <label>500 to 1000</label>
          
          <br />
          <input type="radio" className="cuisinOption" name="cost" />
            <label>1000 to 1500</label>
          
          <br/>
          <input type="radio" className="cuisinOption" name="cost" />
            <label>1500 to 2000</label>
          
          <br/>
          <input type="radio" className="cuisinOption" name="cost" />
            <label>2000+</label>
        
        <br/>
        <div className="filterPanelSubHeading">
          Sort
        </div>
        <input type="radio" className="cuisinOption" name="price" />
          <label>Price low to high</label>
       
        <br/>
        <input type="radio" className="cuisinOption" name="price" />
          <label>Price high to low</label>
        
        <br/>
        </div>
      </div>
      <div className="col-sm-12 col-md-8 col-lg-9">
        <div className="resultPanel">
          <div className="row upperSection">
            <div className="col-2">
              <img src="https://b.zmtcdn.com/data/dish_photos/6a3/c5b5044bd1f8cf94b946af4bfe0936a3.jpg?output-format=webp" alt="Notfound" className="resultsImage"/>
            </div>
            <div className="col-10">
              <div className="resultsHeading">Vanberry</div>
              <div className="resultsSubHeading">Salem</div>
              <div className="resultsAddress">Alagapuram Pudur, Salem</div>
            </div>
          </div>
          <hr />
          <div className="row lowerSection">
            <div className="col-2">
              <div className="resultsAddress">CUISINES:</div>
              <div className="resultsAddress">COST FOR TWO:</div>
            </div>
            <div className="col-10">
              <div className="resultsSubHeading">Bakery:</div>
              <div className="resultsSubHeading">700</div>
            </div>
          </div>
        </div>
        <div className="resultPanel">
          <div className="row upperSection">
            <div className="col-2">
              <img src="https://b.zmtcdn.com/data/dish_photos/6a3/c5b5044bd1f8cf94b946af4bfe0936a3.jpg?output-format=webp" alt="Notfound"className="resultsImage"/>
            </div>
            <div className="col-10">
              <div className="resultsHeading">Vanberry</div>
              <div className="resultsSubHeading">Salem</div>
              <div className="resultsAddress">Alagapuram Pudur, Salem</div>
            </div>
          </div>
          <hr/>
          <div className="row lowerSection">
            <div className="col-2">
              <div className="resultsAddress">CUISINES:</div>
              <div className="resultsAddress">COST FOR TWO:</div>
            </div>
            <div className="col-10">
              <div className="resultsSubHeading">Bakery:</div>
              <div className="resultsSubHeading">700</div>
            </div>
          </div>
        </div>
        <div className="pagination d-flex justify-content-center">
          <nav aria-label="Page navigation example">
            <ul className="pagination">
              <li className="page-item">
                <a className="page-link" href="https://www.zomato.com/" aria-label="Previous">
                  <span aria-hidden="true">&laquo;</span>
                </a>
              </li>
              <li className="page-item"><a className="page-link" href="https://www.zomato.com/">1</a></li>
              <li className="page-item"><a className="page-link" href="https://www.zomato.com/">2</a></li>
              <li className="page-item"><a className="page-link" href="https://www.zomato.com/">3</a></li>
              <li className="page-item"><a className="page-link" href="https://www.zomato.com/">4</a></li>
              <li className="page-item"><a className="page-link" href="https://www.zomato.com/">5</a></li>
              <li className="page-item"><a className="page-link" href="https://www.zomato.com/"><span >&raquo;</span></a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
    </div>
    </div>

            
        )
    }
}
export default Filter;