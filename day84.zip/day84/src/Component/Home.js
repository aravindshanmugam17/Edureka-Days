import React from 'react';
import '../Styles/home.css';

import QuickSearch from './QuickSearch';
import Wallpaper from './Wallpaper';
import axios from 'axios';
class Home extends React.Component{
    constructor(){
        super();
        this.state={
            locations:[]
        }
    }
    
    componentDidMount(){
        axios({
            method:'GET',
            url:'http://localhost:3000/locations',
            headers:{'Content-Type':'application/json'}
        })
        .then(response=>{
            this.setState({locations: response.data})
        })
        .catch(err=>console.log(err))
    }


    render(){
        const{locations}=this.state
        return(
            <div>
                 <Wallpaper  locationsData={locations} />
                 <QuickSearch/>
               
             </div>
      
         
             )
          }
      }

export default Home;
