import React from "react";
import '../Styles/header.css';

class Header extends React.Component{
    constructor(){
        super();
        this.state={
            backgroundColor: '',
            display: 'none'
        }
    }
    componentDidMount(){
        const path = this.props.history.location.pathname;
        this.setAttributes(path);
    }
    setAttributes = (path) => {
        let bg,display;
        if (path == '/'){
            bg = 'black';
            display = 'none';
        }
        else{
            bg = 'red';
            display= 'inline-block';
        }
        this.setState({backgroundColor: bg,display:display});
    }
    render(){
        const {backgroundColor, display} =this.state ;
        return (
            <div className="top" style={{backgroundColor: backgroundColor}}>
                <div className="Logo" style={{display : display}}>
                <p>e!</p>
                </div>
                <button className="Login">Login</button>
                <button className="Createaccount">
                    Create account</button>
                
            </div>
        )
    }
}
export default Header ;