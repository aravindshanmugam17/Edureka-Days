import logo from './logo.svg';
import './App.css';
import Count from './components/counter';
import Hookexample from './components/Hooks';


function App() {
  return (
    <div>
      <Count />
      <Hookexample />
    </div>
  );
}

export default App;
