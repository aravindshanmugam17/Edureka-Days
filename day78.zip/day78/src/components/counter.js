import React,{useState} from "react";


const Count =()=>{
    const initialCount=0
   const[count,setcount]=useState(initialCount);
return(
    <>
    <h1>{count}</h1>
    <button style={{backgroundColor:"yellow"}} onClick={()=>{setcount(prevcount=>prevcount-1)}}><h3>Decrement</h3></button>
    <button  style={{backgroundColor:"yellow",color:"red"}}onClick={()=>{setcount(initialCount)}}><h3>Reset</h3></button>
    <button style={{backgroundColor:"yellow"}} onClick={()=>{setcount(prevcount=>prevcount+1)}}><h3>Increment</h3></button>
    </>
)

}
export default Count