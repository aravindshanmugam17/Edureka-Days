import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import '../components/Styles/style.css'

const Hookexample = ()=>{
    const [posts,setposts]=useState([])
    const [originalposts,setoriginalposts]=useState([])
    const [inputtext,setinputtext]=useState([])

    useEffect(()=>{
        fetch('https://jsonplaceholder.typicode.com/posts')
        .then(response=>response.json())
        .then(res=>{
            setposts(res);
            setoriginalposts(res)
        })

        .catch(err=>{
            console.log(err);
        })
    },[])

    return(
        <>
        <h1><input type="text" onChange={(event)=>{setinputtext(event.target.value)}} /></h1>
        <button  style={{backgroundColor:"yellow",color:"black"}} onClick={()=>{
            let arr;
            if(inputtext != ''){
                arr=originalposts.filter(item=>item.id == Number(inputtext))
            }
            else{
                arr=originalposts
            }
            setposts(arr)
        }}><h2>Submit</h2>
        </button>

        {
            posts.map((item)=>{
                return<div className="hook">
                    <h4>{`${item.id}-${item.title}`}</h4>
                    <div>{item.body}</div>
                </div>
            })
        }
        
        </>
    )

}
export default Hookexample