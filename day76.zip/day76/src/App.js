import React from "react";
import { BrowserRouter, Routes, Route, NavLink, Link } from "react-router-dom";
import Home from "./Components/Home";
import About from "./Components/About";
import Contact from "./Components/Contact";
import ProductDetails from "./Components/ProductDetail";
import Page2 from "./Components/Page2";
import Page3 from "./Components/Page3";
import Page4 from "./Components/page4";
import Page5 from "./Components/Page5";
import Page6 from "./Components/Page6";
import Page7 from "./Components/Page7";
import Page8 from "./Components/Page8";
import Page9 from "./Components/Page9";
import Page10 from "./Components/Page10";

class App extends React.Component {
render(){
	return (
		<>
			 <BrowserRouter>
				
        <button>
          <Link to="/">HOME</Link>
        </button>
        <button>
          <Link to="/about">ABOUT</Link>
        </button>
        <button>
          <Link to="/products">PRODUCT</Link>
        </button>
				<Routes>
					<Route exact path="/" element={<Home />} />
					<Route exact path="/about" element={<About />} />
					<Route exact path="/products" element={<Contact />} />
					
					<Route exact path="/products/1" element={<ProductDetails />} />
					<Route exact path="/products/2" element={<Page2 />} />
					<Route exact path="/products/3" element={<Page3 />} />
					<Route exact path="/products/4" element={<Page4 />} />
					<Route exact path="/products/5" element={<Page5 />} />
					<Route exact path="/products/6" element={<Page6 />} />
					<Route exact path="/products/7" element={<Page7 />} />
					<Route exact path="/products/8" element={<Page8 />} />
					<Route exact path="/products/9" element={<Page9 />} />
					<Route exact path="/products/10" element={<Page10 />} />
          </Routes>
			</BrowserRouter>
		</>
	);
}
}

export default App;
