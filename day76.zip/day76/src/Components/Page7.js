
import React from "react";

class Page7 extends React.Component{
    
    render(){
    return(
       
        <>
       {<h1 style={{backgroundColor:"yellow"}}>IT'S Product Page 7</h1>}
       
        </>

    )
}
}
 export default Page7;