
import React from "react";

class Page4 extends React.Component{
    
    render(){
    return(
       
        <>
       {<h1>IT'S Product Page 4</h1>}
       
        </>

    )
}
}
 export default Page4;