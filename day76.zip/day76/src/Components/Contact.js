import React from 'react';
import { BrowserRouter, Routes, Route, NavLink, Link } from "react-router-dom";

const product=[1,2,3,4,5,6,7,8,9,10]

class Contact extends React.Component  {
 render(){
  
 return (
	<>
	<h1> Product  </h1>
     
    <button>
        <Link to="/products/1"> 1</Link>
    </button>
     
    <button>
        <Link to="/products/2"> 2</Link>
    </button>

 
    <button>
        <Link to="/products/3"> 3</Link>
    </button>

 
    <button>
        <Link to="/products/4"> 4</Link>
    </button>

 
    <button>
        <Link to="/products/5"> 5</Link>
    </button>

 
    <button>
        <Link to="/products/6"> 6</Link>
    </button>
 
    <button>
        <Link to="/products/7"> 7</Link>
    </button>
 
    <button>
        <Link to="/products/8"> 8</Link>
    </button>
 
    <button>
        <Link to="/products/9"> 9</Link>
    </button>
 
    <button>
        <Link to="/products/10"> 10</Link>
    </button>



</>
)
}
};

export default Contact;
