
import React from "react";

class Page10 extends React.Component{
    
    render(){
    return(
       
        <>
       {<h1 style={{backgroundColor:"yellow"}}>IT'S Product Page 10</h1>}
       
        </>

    )
}
}
 export default Page10;