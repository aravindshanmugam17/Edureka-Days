
import React from "react";

class ProductDetails extends React.Component{
    
    render(){
    return(
       
        <>
       {<h1>IT'S Product Page 1</h1>}
       
        </>

    )
}
}
 export default ProductDetails;