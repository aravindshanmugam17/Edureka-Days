
import React from "react";

class Page2 extends React.Component{
    
    render(){
    return(
       
        <>
       {<h1>IT'S Product Page 2</h1>}
       
        </>

    )
}
}
 export default Page2;