
import React from "react";

class Page6 extends React.Component{
    
    render(){
    return(
       
        <>
       {<h1>IT'S Product Page 6</h1>}
       
        </>

    )
}
}
 export default Page6;