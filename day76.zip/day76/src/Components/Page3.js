
import React from "react";

class Page3 extends React.Component{
    
    render(){
    return(
       
        <>
       {<h1>IT'S Product Page 3</h1>}
       
        </>

    )
}
}
 export default Page3;