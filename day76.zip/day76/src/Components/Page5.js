
import React from "react";

class Page5 extends React.Component{
    
    render(){
    return(
       
        <>
       {<h1>IT'S Product Page 5</h1>}
       
        </>

    )
}
}
 export default Page5;