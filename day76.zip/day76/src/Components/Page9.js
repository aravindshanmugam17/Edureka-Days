
import React from "react";

class Page9 extends React.Component{
    
    render(){
    return(
       
        <>
       {<h1 style={{backgroundColor:"yellow"}}>IT'S Product Page 9</h1>}
       
        </>

    )
}
}
 export default Page9;