import logo from './logo.svg';
import './App.css';
import React, { Component } from 'react';
import A from './Components/A';
import users from './Components/Users';

export const OrganizationContext=React.createContext()
export const CourseContext =React.createContext()
export const UsersContext=React.createContext()

function App() {
  return (
    <div className="App">
      <OrganizationContext.Provider value='Edureka !'>
        <CourseContext.Provider value='Full-Stack Web Development'>
          <UsersContext.Provider value={users}>
            <A />
          </UsersContext.Provider>
        </CourseContext.Provider>
      </OrganizationContext.Provider>
      
    </div>
  );
}

export default App;
