import React from "react";

import C from "./C";

function B(){
    return(
        <div>
            <C/>
        </div>
    )

}
export default B