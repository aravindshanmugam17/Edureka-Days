
const users =[{firstName:"Lena", lastName:"Smith", rollNo: 12,},
{firstName: "Tom", lastName:"Taylor", rollNo: 16,},
{firstName:"Jhon", lastName:"smith", rollNo: 87,},]
export default users