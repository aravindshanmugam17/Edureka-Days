import React ,{useContext}from "react";
import { CourseContext,OrganizationContext,UsersContext } from "../App";

function C(){
    const Organization=useContext(OrganizationContext)
    const Course =useContext(CourseContext)
    const users=useContext(UsersContext)
    return(
        <div>
            <h1>{`organization : ${Organization}`}</h1>
            <h1>{`course : ${Course}`}</h1>
            <table width={1200}border={1}>
               <tr style={{backgroundColor:"skyblue",fontWeight:"10pX"}}>
                <td>First Name</td>
                <td>Last Name</td>
                <td>Roll.No</td>
               </tr>
               {
                
                users.map((item)=>{
                    return <tr style={{backgroundColor:"skyblue"}} >
                        <td>{item.firstName}</td>
                        <td>{item.lastName}</td>
                        <td>{item.rollNo}</td>
                    </tr>
                })
               }
            </table>
        </div>
    )

}
export default C