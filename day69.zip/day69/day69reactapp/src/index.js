import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

const  title1 =React.createElement('h1',null,'edureka');
const  title2 =React.createElement('h2',null,'happy Learning!');

ReactDOM.render([title1,title2],document.getElementById('root'));

 
 
