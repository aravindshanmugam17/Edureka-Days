import React from "react";
import { render } from "react-dom";

const Myfunctional=()=>{
    return(
        <div>
            <h1>It's Myfirst Functional Components...</h1>
        </div>
    )
}
export default Myfunctional ;