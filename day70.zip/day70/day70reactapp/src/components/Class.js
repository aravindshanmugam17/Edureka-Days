import React from "react";

class MyClass extends React.Component{
    render(){
        return(
            <div>
                <h1>It's Myfirst Class  Components...</h1>
            </div>
        )
    }
}
export default MyClass;