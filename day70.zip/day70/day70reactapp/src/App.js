import logo from './logo.svg';
import './App.css';
import React from 'react';

//import Myfunctional from './components/Funtional';

// function App() {
//   return (
//     <div className="App">
//       <Myfunctional />
//     </div>
//   );
// }



import MyClass from './components/Class';

class App extends React.Component{
  render(){
    return(
      <MyClass />
    )
  }
}
export default App;
