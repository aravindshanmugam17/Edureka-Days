import React from "react";
import '../Styles/filter.css'
 
class Detail extends React.Component{
    render(){
        return(
     <div>
           <div className="col-9 col-sm-12 col-md-8 col-lg-9">
           <img src="https://media.istockphoto.com/id/500516612/photo/enjoying-dinner-with-friends.jpg?s=1024x1024&w=is&k=20&c=ply0ofr8l0DhhYyyV6rn9oKVAZwzag_4fy5ICBwnHUI=" alt="image not found" width="100%" height="550px" />

             <div className="resultspanel">
                <div className="row uppersection">
                   <div className="col-2">

                      <img className="resultsimage" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyJYwX2qCYCa8cYiY7j3hITYAdQF-36Bxdig&usqp=CAU" alt="image not found " />
                   </div>
                   <div className="col-10">
                    <div className="resultsheading">THE BIG CHILL CAKE</div>
                    <div className="resultssubheading">Fort</div>
                    <div className="resultsaddress">shop:1, plat D, salem-636104</div>
                  </div>
                </div><hr></hr>
               <div className="row lowersection">
                  <div className="col-2">
                     <div className="resultsaddress"> CUISINE:</div>
                     <div className="resultsaddress">COST FOR TWO:</div>
                  </div>
                  <div className="col-10">
                     <div className="resultssubheading"> BAKERY</div>
                     <div className="resultssubheading">&#8377;700</div>
                  </div>
               </div>
            </div>
            
         </div>
        </div>
      
        )
    }
}
export default Detail