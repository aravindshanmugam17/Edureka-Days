import React from "react";
import { Route,BrowserRouter, Routes } from "react-router-dom";
import Home from "./Home";
import Filter from "./Filters"
import Detail from "./Details";
import Header from "./Header";

function ROUTERS(){
    return(
       <BrowserRouter>
       <Header />
       <Routes>
       <Route exact path = '/' Component={Home} />
       <Route  path ='/filter' Component={Filter}/>
       <Route  path ='/details' Component={Detail}/>
       </Routes>
       </BrowserRouter>
    )
}
export default ROUTERS