import React from "react";
import Quicksearchitems from "./Quicksearchitem";

class Quickserach extends React.Component{
    render(){
        return(
            <div>
                <div className="bottomsection">
                 <h1 className="qs-heading">Quick Searches</h1>
                  <h3 className="qs-subheading">Discover restarunts by type of meal</h3>
                   <div className="qs-boxes-container row">
                     <Quicksearchitems />
                   </div>
                 </div>
            </div>
        )
    }
}
export default Quickserach