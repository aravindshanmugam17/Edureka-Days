import React from "react";
import '../Styles/filter.css'
 
class Filter extends React.Component{
    render(){
        return(
     <div>
          <div classNameName="container">
           <div className="row heading">
                  Breakfast Places in mumbai
            </div>
          <div className="row">
          <div className="col-3 col-sm-4 col-md-4 col-lg-3">
              <div className="filterpanel">
              <div className="filterpanelheading">
                  Filter/Sorting
              </div>
              <div className="filtersubheading">
                  SELECT LOCATIONS
              </div><br></br>
              <select className="selectlocation">
                <option selected disabled>--choose the location--</option>
                <option value={"delhi"}>Delhi</option>
                <option value={"bangalore"}>Bangalore</option>
                <option value={"mumbai"}>Mumbai</option>
                <option value={"pune"}>Pune</option>
                <option value={"chennai"}>Chennai</option>
                <option value={"kolkata"}>Kolkata</option>
              </select>
               <div className="filterpanelsubheading">
                   CUISINE
               </div>
                 <input type="checkbox" className="cuisineoption"/>
                 <label for="">{"North-Indian"}</label>
                 
                 <br/>
                 <input type="checkbox" className="cuisineoption" />
                 <label for="">{"South  Indian"}</label>
                 <br />
                 <input type="checkbox" className="cuisineoption" />
                 <label for=""> {"Chinise"}</label>
                
                 <br/>
                 <input type="checkbox" className="cuisineoption" />
                 <label for=""> {"Street Food"}</label>

                 <br/>
                 <input type="checkbox" className="cuisineoption" />
                 <label for="">{"Fast Food"}</label>
                 
                 <br />
                 <div className="filterpanelsubheading">
                  COST FOR TWO:
                 </div>
                  <input type="radio" className="cuisineoption" name="cost" />
                  <label for="">Less-than &#8377;500</label>
                  <br/>
                  <input type="radio" className="cuisineoption" name="cost" />
                  <label for=""> &#8377;500 to &#8377;1000</label>
                  <br />
                  <input type="radio" className="cuisineoption" name="cost" />
                  <label for=""> &#8377;1000 to &#8377;1500</label>
                  <br />
                  <input type="radio" className="cuisineoption" name="cost" />
                  <label for=""> &#8377;1500 to  &#8377;2000</label>
                  <br/>
                  <input type="radio" className="cuisineoption" name="cost"/>
                  <label for=""> &#8377;2000+</label>
                  <br/>
                <div className="filterpanelsubheading">
                    SORT
                </div>
                  <input type="radio" className="cuisineoption" name="price"/>
                   <label for=""> {"Price low to high"}</label>
                  <br/>
                  <input type="radio" className="cuisineoption" name="price" />
                   <label for=""> {"Price high to low"}</label>
                  <br/>
               </div>
         </div>
         <div className="col-9 col-sm-12 col-md-8 col-lg-9">
            <div className="resultspanel">
               <div className="row uppersection">
                  <div className="col-2">
                     <img className="resultsimage" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyJYwX2qCYCa8cYiY7j3hITYAdQF-36Bxdig&usqp=CAU" alt="image not found"/>
                  </div>
                  <div className="col-10">
                    <div className="resultsheading">THE BIG CHILL CAKE</div>
                    <div className="resultssubheading">Fort</div>
                    <div className="resultsaddress">shop:1, plat D, salem-636104</div>
                  </div>
               </div><hr />
               <div className="row lowersection">
                  <div className="col-2">
                     <div className="resultsaddress"> CUISINE:</div>
                     <div className="resultsaddress">COST FOR TWO:</div>
                  </div>
                  <div className="col-10">
                     <div className="resultssubheading"> BAKERY</div>
                     <div className="resultssubheading">&#8377;700</div>
                  </div>
               </div>
             </div>
             <div className="resultspanel">
                <div className="row uppersection">
                   <div className="col-2">
                      <img className="resultsimage" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyJYwX2qCYCa8cYiY7j3hITYAdQF-36Bxdig&usqp=CAU" alt="image not found " />
                   </div>
                   <div className="col-10">
                    <div className="resultsheading">THE BIG CHILL CAKE</div>
                    <div className="resultssubheading">Fort</div>
                    <div className="resultsaddress">shop:1, plat D, salem-636104</div>
                  </div>
                </div><hr></hr>
               <div className="row lowersection">
                  <div className="col-2">
                     <div className="resultsaddress"> CUISINE:</div>
                     <div className="resultsaddress">COST FOR TWO:</div>
                  </div>
                  <div className="col-10">
                     <div className="resultssubheading"> BAKERY</div>
                     <div className="resultssubheading">&#8377;700</div>
                  </div>
               </div>
            </div>
            <div className="pagination">
               <div className="paginationbutton"> 0</div>
               <div className="paginationbutton">1</div>
               <div className="paginationbutton">2</div>
               <div className="paginationbutton">3</div>
               <div className="paginationbutton">4</div>
               <div className="paginationbutton">5</div>
               <div className="paginationbutton">6</div>
            </div>
         </div>

         
        </div>
       </div>
    </div>
        )
    }
}
export default Filter