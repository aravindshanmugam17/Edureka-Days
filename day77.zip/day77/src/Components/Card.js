import React from "react";

import  '../Styles/card.css';

class Card extends React.Component {
    render() {
        return (
            <div>
              <div style={{backgroundColor: 'greenyellow',
                width: '300px',
                height: '150px',
                border: '1px solid black'
                }}>
             </div>

              <div className="card"></div>

            </div>
        )
    }
}

export default Card;