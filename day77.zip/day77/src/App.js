import logo from './logo.svg';
import './App.css';
import Card from './Components/Card';
import React from "react";

import './Styles/card.css';

class App extends React.Component{
  render() {
    return(
<Card/>
    )
  }
}

            

export default App;
