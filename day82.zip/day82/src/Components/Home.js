import React from "react";
import '../Styles/home.css'
import Wallpaper from "./Wallpaper";
import Quickserach from "./Quicksearch";
class Home extends React.Component{
    render(){
    return(
     <div>
         <Wallpaper />
         < Quickserach />
      </div>
        )
    }
}

export default Home